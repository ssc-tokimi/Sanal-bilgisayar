# Yalnızca telefon kullanarak APK oluşturma

Bu paket APK'nın kendisi değil; Android APK'sını ücretsiz bir bulut derlemesinde oluşturmak için kaynak dosyaları ve GitHub Actions iş akışını içerir.

## Adımlar
1. GitHub hesabınla yeni, **Private** bir repository oluştur.
2. Repository içine `SanalPC-Android-Proje.zip` dosyasını yükle.
3. Repository'de **Add file → Create new file** seç.
4. Dosya adını tam olarak `.github/workflows/android-build.yml` yap.
5. Bu paketteki `.github/workflows/android-build.yml` dosyasının içeriğini yapıştır ve kaydet.
6. Repository'nin **Actions** sekmesine gir. İlk seferde iş akışını etkinleştirmen istenirse etkinleştir.
7. **Build SanalPC APK** iş akışını seç, **Run workflow** düğmesine bas.
8. İşlem başarılı olursa tamamlanan çalışmanın altındaki **Artifacts** bölümünden `SanalPC-debug-APK` dosyasını indir.
9. İndirilen artifact ZIP'ini telefonda aç; içindeki `app-debug.apk` dosyasına dokunarak yükle.

## Güvenlik ve beklenti
- GitHub hesabı ve internet bağlantısı gerekir. Repository'yi Private tutman önerilir.
- APK yalnızca iş akışı başarıyla tamamlanırsa oluşur. Hata olursa Actions günlüklerindeki hata mesajına bakılmalıdır.
- Bu proje arayüz prototipidir: gerçek Windows/sanal makine veya PC oyun çalıştırıcısı değildir. Dokunmatik tuşlar şu an uygulamanın kendi arayüzüne olay gönderir.
