# SanalPC Android prototipi (v0.1)

Bu Android Studio projesi, telefonda çalışan bir masaüstü arayüzü demosu ve kişiselleştirilebilir dokunmatik tuş katmanı içerir.

## Şu an çalışanlar
- Yatay ekranlı Android uygulaması (WebView içinde yerel arayüz)
- Masaüstü simgeleri, örnek pencereler, görev çubuğu ve saat
- Sınırsız tuş ekleme (tarayıcı/cihaz belleği sınırları dahilinde), tuş adını ve gönderilecek klavye/fare eylemi etiketini düzenleme
- Tuşları sürükleyerek konumlandırma, boyut ve şeffaflık ayarı
- Her tuşu ayrı gizleme/gösterme, tüm tuşları açıp kapatma ve yerleşimi sıfırlama
- Tuş yerleşimini localStorage ile saklama

## Önemli sınırlar
Bu sürüm gerçek Windows veya Linux sanal makinesi değildir. Terminal, dosya gezgini, uygulama merkezi ve oyun kütüphanesi ekranları prototip arayüzleridir. Tuşlar yalnızca uygulamanın kendi WebView içeriğine olay gönderir; Android'deki başka uygulamalara veya gerçek PC oyunlarına sistem genelinde tuş gönderemez. Gerçek PC oyunları için ARM uyumluluk/çeviri katmanı, grafik sürücüleri ve uygun bir oyun çalıştırma motoru ayrıca entegre edilmelidir. Bu yüzden Steam/GTA/Windows oyunlarının bu prototipte kurulması veya çalışması beklenmemelidir.

## APK oluşturma
1. Android Studio'yu bir bilgisayara kur.
2. Bu klasörü `Open` ile aç.
3. Android SDK Platform 35 ve Android Gradle Plugin bağımlılıklarının indirilmesini bekle.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seç.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` altında oluşur.

Komut satırı: `gradle assembleDebug` (Gradle ve Android SDK kuruluysa).

Min SDK: Android 8.0 (API 26). Proje Android Studio/Gradle ile derlenmek üzere hazırlanmıştır; bu ortamda APK derlemesi doğrulanmamıştır.
